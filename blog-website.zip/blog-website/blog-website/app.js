const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const methodOverride = require('method-override');
const blogRoutes = require('./routes/blogs');

const app = express();

// Connect to MongoDB
mongoose.connect('mongodb://127.0.0.1:27017/blogApp',);

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(methodOverride('_method'));
app.use(express.static('public'));

// Set view engine to ejs
app.set('view engine', 'ejs');

// Routes
app.use('/blogs', blogRoutes);

// Home route
app.get('/', (req, res) => {
    res.redirect('/blogs');
});

// Start the server
const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
