const express = require('express');
const Blog = require('../models/Blog');

const router = express.Router();

// INDEX Route: Show all blogs
router.get('/', async (req, res) => {
    const blogs = await Blog.find({});
    res.render('index', { blogs });
});

// NEW Route: Show form to create a new blog
router.get('/new', (req, res) => {
    res.render('new');
});

// CREATE Route: Add new blog to database
router.post('/', async (req, res) => {
    await Blog.create(req.body.blog);
    res.redirect('/blogs');
});

// SHOW Route: Show one blog
router.get('/:id', async (req, res) => {
    const blog = await Blog.findById(req.params.id);
    res.render('show', { blog });
});

// EDIT Route: Show edit form for one blog
router.get('/:id/edit', async (req, res) => {
    const blog = await Blog.findById(req.params.id);
    res.render('edit', { blog });
});

// UPDATE Route: Update a blog in the database
router.put('/:id', async (req, res) => {
    await Blog.findByIdAndUpdate(req.params.id, req.body.blog);
    res.redirect(`/blogs/${req.params.id}`);
});

// DELETE Route: Delete a blog from the database
router.delete('/:id', async (req, res) => {
    await Blog.findByIdAndDelete(req.params.id);
    res.redirect('/blogs');
});

module.exports = router;
